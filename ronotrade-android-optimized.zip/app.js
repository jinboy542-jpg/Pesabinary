let balance=1000,pl=0,trades=[],wins=0,losses=0;
const demoTrades=[
 {asset:"BTC/USD",dir:"UP",amount:50,result:"+$40.00",status:"Won"},
 {asset:"EUR/USD",dir:"DOWN",amount:25,result:"-$25.00",status:"Lost"},
 {asset:"GOLD",dir:"UP",amount:100,result:"+$80.00",status:"Won"}
];
trades=[...demoTrades];wins=2;losses=1;pl=95;
function money(n){return Number(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}
function update(){document.getElementById("balance").textContent=money(balance);document.getElementById("sideBal").textContent=money(balance);document.getElementById("mobileBalance").textContent=money(balance);document.getElementById("pl").textContent=(pl>=0?"+$":"-$")+money(Math.abs(pl));document.getElementById("open").textContent="0";document.getElementById("winrate").textContent=(wins+losses?Math.round(wins/(wins+losses)*100):0)+"%"}
function render(){document.getElementById("trades").innerHTML=trades.slice(0,8).map(t=>`<tr><td>${t.asset}</td><td class="${t.dir==="UP"?"result-win":"result-loss"}">${t.dir==="UP"?"▲ UP":"▼ DOWN"}</td><td>$${money(t.amount)}</td><td class="${String(t.result).startsWith("+")?"result-win":"result-loss"}">${t.result}</td><td><span class="status">${t.status}</span></td></tr>`).join("");update()}
function trade(dir){const amount=Number(document.getElementById("amount").value);if(!amount||amount<1||amount>balance){msg.textContent="Enter a valid demo amount.";return}balance-=amount;const win=Math.random()>0.45,payout=win?amount*.8:0;balance+=payout;const result=win?`+$${money(payout)}`:`-$${money(amount)}`;pl+=win?payout:-amount;win?wins++:losses++;trades.unshift({asset:asset.value,dir,amount,result,status:win?"Won":"Lost"});msg.textContent=win?`Demo trade won. Result: +$${money(payout)}`:`Demo trade lost. Result: -$${money(amount)}`;render()}
function addFunds(){balance+=100;msg.textContent="Added $100 demo funds.";render()}
function resetDemo(){balance=1000;pl=95;wins=2;losses=1;trades=[...demoTrades];msg.textContent="Demo account reset.";render()}
render();
function scrollToSection(id){
  const el=document.getElementById(id);
  if(el)el.scrollIntoView({behavior:"smooth",block:"start"});
  document.querySelectorAll(".mobile-bar button").forEach(b=>b.classList.remove("mobile-active"));
  const map={top:0,chartCard:1,tradeCard:2,tradesCard:3};
  const buttons=document.querySelectorAll(".mobile-bar button");
  if(map[id]!==undefined&&buttons[map[id]])buttons[map[id]].classList.add("mobile-active");
}

# RonoTrade Better Trading Dashboard

A polished frontend demo trading dashboard with:
- Demo balance
- BTC/USD chart-style market view
- Asset, amount and duration controls
- UP/DOWN demo trades
- Demo P/L and win-rate statistics
- Recent trade history
- Responsive Android/mobile layout
- Demo funds and reset controls

This is a frontend-only practice dashboard. It does not connect to a broker, M-Pesa, bank, real customer funds, or real-money trading.

## Android optimization
- Touch-friendly 44px+ controls
- Bottom navigation for one-hand use
- Safe-area support for modern Android devices
- Mobile balance quick card
- Responsive chart/trading cards
- 16px form controls to prevent mobile browser zoom
- Reduced clutter on small screens
- Smooth navigation and no horizontal overflow

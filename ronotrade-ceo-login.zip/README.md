# RonoTrade Demo — User + CEO/Admin Login

CEO demo login: ceo@ronotrade.demo / Admin123!

This is a frontend-only prototype. The CEO credentials are visible in the JavaScript and are NOT secure. Do not use this for real customer authentication, KYC, deposits, withdrawals, or real-money trading. A production system needs a secure backend, hashed passwords, sessions/tokens, database, access controls and compliance.

# RonoTrade Better Trading Dashboard

A polished frontend demo trading dashboard with:
- Demo balance
- BTC/USD chart-style market view
- Asset, amount and duration controls
- UP/DOWN demo trades
- Demo P/L and win-rate statistics
- Recent trade history
- Responsive Android/mobile layout
- Demo funds and reset controls

This is a frontend-only practice dashboard. It does not connect to a broker, M-Pesa, bank, real customer funds, or real-money trading.

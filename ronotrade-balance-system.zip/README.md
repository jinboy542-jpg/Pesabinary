# RonoTrade Full CEO Admin Panel

Includes:
- CEO/Admin login
- Overview dashboard
- User management
- Trade monitor
- Demo transaction monitor
- KYC queue placeholder
- Reports center
- Settings
- Responsive Android/mobile layout
- Reads demo registered users from localStorage

Demo CEO login:
Email: ceo@ronotrade.demo
Password: Admin123!

IMPORTANT:
This is a frontend-only prototype. It does not authenticate real users securely, process real deposits/withdrawals, hold customer funds, perform KYC, or connect to a broker. The demo credentials are visible in JavaScript and must never be used as production credentials.

For production, use a secure backend, hashed passwords, server-side sessions/tokens, database, authorization, audit logs, encrypted secrets, and all required legal/regulatory compliance.

## Added: Demo User Balance System
- Every registered demo user starts with $1,000 demo balance.
- CEO can add or remove demo balance by user email.
- User balance, demo deposits and demo withdrawals are tracked locally.
- User balances appear in CEO User Management.
- This is not connected to M-Pesa, a bank, a broker, or real customer funds.

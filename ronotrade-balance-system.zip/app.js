const ADMIN_EMAIL="ceo@ronotrade.demo",ADMIN_PASSWORD="Admin123!";

function currentUser(){
  try{return JSON.parse(localStorage.getItem("ronoCurrentUser")||"null")}catch{return null}
}
function setCurrentUser(u){localStorage.setItem("ronoCurrentUser",JSON.stringify(u))}
function ensureBalances(){
  let u=getUsers(), changed=false;
  u=u.map(x=>{if(typeof x.balance!=="number"){x.balance=1000;changed=true}if(typeof x.deposits!=="number")x.deposits=0;if(typeof x.withdrawals!=="number")x.withdrawals=0;return x});
  if(changed || u.length) localStorage.setItem("ronoUsers",JSON.stringify(u));
  return u;
}
function adjustUserBalance(direction){
  const e=document.getElementById("balanceEmail").value.trim().toLowerCase();
  const amount=Number(document.getElementById("balanceAmount").value);
  if(!e||!amount||amount<=0){balanceMsg.textContent="Enter a user email and a valid amount.";return}
  let u=ensureBalances(), found=u.find(x=>x.email===e);
  if(!found){balanceMsg.textContent="User not found.";return}
  if(direction<0 && Number(found.balance||0)<amount){balanceMsg.textContent="Insufficient demo balance.";return}
  found.balance=Number(found.balance||0)+(direction*amount);
  if(direction>0)found.deposits=Number(found.deposits||0)+amount;
  else found.withdrawals=Number(found.withdrawals||0)+amount;
  localStorage.setItem("ronoUsers",JSON.stringify(u));
  balanceMsg.textContent=`Updated ${found.name}'s demo balance to $${found.balance.toFixed(2)}.`;
  renderUsers();
}
function userBalanceAction(amount){
  const s=currentUser();
  if(!s){userBalanceMsg.textContent="No demo user is signed in.";return}
  let u=ensureBalances(), found=u.find(x=>x.email===s.email);
  if(!found){userBalanceMsg.textContent="Demo account not found.";return}
  if(amount<0 && found.balance<Math.abs(amount)){userBalanceMsg.textContent="Insufficient demo balance.";return}
  found.balance+=amount;
  if(amount>0)found.deposits+=amount; else found.withdrawals+=Math.abs(amount);
  localStorage.setItem("ronoUsers",JSON.stringify(u));
  setCurrentUser(found);
  renderUserBalance();
  userBalanceMsg.textContent=`Demo balance updated to $${found.balance.toFixed(2)}.`;
}
function renderUserBalance(){
  const s=currentUser(); if(!s)return;
  const u=ensureBalances(), found=u.find(x=>x.email===s.email); if(!found)return;
  myBalance.textContent="$"+Number(found.balance||0).toFixed(2);
  myDeposits.textContent="$"+Number(found.deposits||0).toFixed(2);
  myWithdrawals.textContent="$"+Number(found.withdrawals||0).toFixed(2);
}

function login(){const e=email.value.trim().toLowerCase(),p=password.value;if(e!==ADMIN_EMAIL||p!==ADMIN_PASSWORD){loginMsg.textContent="Invalid CEO credentials.";return}sessionStorage.setItem("ronoAdmin","1");openApp()}
function openApp(){login.classList.add("hidden");app.classList.remove("hidden");renderUsers();renderActivity()}
function logout(){sessionStorage.removeItem("ronoAdmin");location.reload()}
function page(id,btn){document.querySelectorAll(".section").forEach(x=>x.classList.add("hidden"));document.getElementById(id).classList.remove("hidden");document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));if(btn)btn.classList.add("active");const titles={overview:"CEO Overview",users:"User Management",trades:"Trade Monitor",transactions:"Transactions",kyc:"KYC Queue",reports:"Reports Center",settings:"Admin Settings"};pageTitle.textContent=titles[id]||"CEO Overview"}
function getUsers(){try{return JSON.parse(localStorage.getItem("ronoUsers")||"[]")}catch{return[]}}
function renderUsers(){const u=ensureBalances();totalUsers.textContent=u.length;activeUsers.textContent=u.length;const q=(userSearch?.value||"").toLowerCase();const rows=u.filter(x=>(x.name+" "+x.email).toLowerCase().includes(q));usersTable.innerHTML=rows.length?rows.map((x,i)=>`<tr><td>${esc(x.name)}</td><td>${esc(x.email)}</td><td>${x.created||"—"}</td><td><b>$${Number(x.balance||0).toFixed(2)}</b></td><td><i class="ok">Active</i></td><td><button class="small" onclick="viewUser('${esc(x.email)}')">View</button></td></tr>`).join(""):`<tr><td colspan="5">No users found.</td></tr>`}
function viewUser(e){alert("Demo user profile:\\n"+e+"\\n\\nNo real customer data is stored by this prototype.")}
function renderActivity(){activity.innerHTML=`<div class="activity-item"><b>CEO dashboard accessed</b><span>Just now</span></div><div class="activity-item"><b>Demo platform status checked</b><span>2 minutes ago</span></div><div class="activity-item"><b>Demo trade recorded</b><span>5 minutes ago</span></div>`}
function downloadReport(type){const data=type==="users"?JSON.stringify(getUsers(),null,2):"RonoTrade demo report\\nType: "+type+"\\nGenerated: "+new Date().toISOString();const blob=new Blob([data],{type:"text/plain"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="ronotrade-"+type+"-report.txt";a.click();URL.revokeObjectURL(a.href)}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
if(sessionStorage.getItem("ronoAdmin")==="1")openApp();